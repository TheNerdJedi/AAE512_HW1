
//
// Exercise 1-3 from Kernighan and Ritchie
//

#include<iomanip>
#include<iostream>
#include<cstdlib>
using namespace std;

int main(void) {
  cout << "T (F)  T (C)" << endl;
  cout << "-----  -----" << endl;

  int lower = 0;
  int upper = 300;
  int step = 20;

  float fahr = lower;
  
  while (fahr <= upper) {
    float celsius = (5./9.) * (fahr-32.);
    cout << " " << fixed << setw(3) << setprecision(0) << fahr << "  ";
    cout << fixed << setw(6) << setprecision(1) << celsius << endl;
    fahr += step;
  }

  return EXIT_SUCCESS;
}



