#!/usr/bin/env python3

#
# Exercise 1-3 from Kernighan and Ritchie
#

print("T (F)  T(C)")
print("-----  ----")

lower = 0
upper = 300
step = 20

fahr = lower

while (fahr <= upper):
    celsius = (5./9.) * (fahr-32.)
    print("%3.0f  %6.1f" % (fahr, celsius))
    fahr = fahr + step
